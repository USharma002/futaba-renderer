#include "common.cuh" // Touch to trigger PTX rebuild 2
#include "heatmap.cuh"
#include "albedo.cuh"
#include "phong.cuh"
#include "depth.cuh"
#include "primitives.cuh"
#include "launch_params.h"
#include "normals.cuh"
#include "path.cuh"
#include "volpath.cuh"
#include "power_sampler.cuh"
#include "tonemapping.cuh"
#include "perspective.cuh"
#include "scene.cuh"
#include "types.cuh"
#include <optix.h>

extern "C" {
__constant__ unsigned char params_buffer[sizeof(futaba::LaunchParams)];
}

using namespace futaba;

#define params (*reinterpret_cast<const LaunchParams *>(params_buffer))

static __device__ Ray3f setup_ray(uint3 idx, int& index, Sampler& sampler) {
  index = idx.y * params.width + idx.x;

  unsigned int seed = (unsigned int)(index + 1) ^ (params.sampleCount << 16);
  sampler = Sampler(seed);

  float jx = params.use_antialiasing ? sampler.next1D() : 0.5f;
  float jy = params.use_antialiasing ? sampler.next1D() : 0.5f;
  float u = (float)(idx.x + jx) / (float)params.width;
  float v = (float)(idx.y + jy) / (float)params.height;

  return params.camera.sampleRay(u, v, sampler);
}

static __device__ void accumulate_and_write(int index, const Ray3f& ray, const Color3f& radiance) {
  Color3f acc = params.film_pixels[index];
  acc += radiance;
  params.film_pixels[index] = acc;

  if (params.denoise_active) {
    SurfaceIntersection si;
    Color3f alb(0.f);
    Vector3f norm(0.f);
    if (params.scene.intersect(ray, ray.mint, ray.maxt, si)) {
      alb = si.albedo;
      norm = Vector3f(dot(si.n, params.camera.right),
                      dot(si.n, params.camera.trueUp),
                      dot(si.n, params.camera.forward));
    } else {
      alb = params.scene.eval_environment(ray.d);
    }

    if (params.sampleCount == 1) {
      params.denoise_albedo_buffer[index] = alb;
      params.denoise_normal_buffer[index] = norm;
    } else {
      params.denoise_albedo_buffer[index] += alb;
      params.denoise_normal_buffer[index] += norm;
    }
  } else {
    Color3f linear_avg = acc / (float)params.sampleCount;
    Color3f tonemapped = tonemap::apply(linear_avg, params.tonemapping_mode);
    Color3f final_color = toSRGB(tonemapped);

    params.pbo_ptr[index].x =
        (unsigned char)clamp(final_color.x * 255.f, 0.f, 255.f);
    params.pbo_ptr[index].y =
        (unsigned char)clamp(final_color.y * 255.f, 0.f, 255.f);
    params.pbo_ptr[index].z =
        (unsigned char)clamp(final_color.z * 255.f, 0.f, 255.f);
    params.pbo_ptr[index].w = 255;
  }
}

extern "C" __global__ void __raygen__render() {
  uint3 idx = optixGetLaunchIndex();

  if (idx.x >= params.width || idx.y >= params.height)
    return;

  int index;
  Sampler sampler;
  Ray3f ray = setup_ray(idx, index, sampler);
  Color3f radiance;
  switch (params.integrator_mode) {
    case INTEGRATOR_NORMALS: {
      Normals normals;
      radiance = normals.sample(ray, params.scene, sampler);
      break;
    }
    case INTEGRATOR_HEATMAP: {
      Heatmap heatmap;
      radiance = heatmap.sample(ray, params.scene, sampler);
      break;
    }
    case INTEGRATOR_ALBEDO: {
      Albedo albedo;
      radiance = albedo.sample(ray, params.scene, sampler);
      break;
    }
    case INTEGRATOR_DEPTH: {
      Depth depth;
      radiance = depth.sample(ray, params.scene, sampler);
      break;
    }
    case INTEGRATOR_PHONG: {
      Phong phong(params.phong_light_dir, params.phong_ambient,
                  params.phong_diffuse, params.phong_specular,
                  params.phong_shininess);
      radiance = phong.sample(ray, params.scene, sampler);
      break;
    }
    case INTEGRATOR_PRIMITIVES:
    default: {
      Primitives primitives;
      radiance = primitives.sample(ray, params.scene, sampler);
      break;
    }
  }

  accumulate_and_write(index, ray, radiance);
}

extern "C" __global__ void __raygen__path() {
  uint3 idx = optixGetLaunchIndex();

  if (idx.x >= params.width || idx.y >= params.height)
    return;

  int index;
  Sampler sampler;
  Ray3f ray = setup_ray(idx, index, sampler);

  Color3f radiance;
  EmitterSampler light_sampler(params.light_sampler_type);
  Path integrator(params.max_depth, params.rr_depth, light_sampler);

  if (params.train_active) {
    TrainingBuffers tb;
    tb.active = params.train_active;
    tb.position = params.train_position;
    tb.normals = params.train_normals;
    tb.wi = params.train_wi;
    tb.wo = params.train_wo;
    tb.radiance = params.train_radiance;
    tb.material_id = params.train_material_id;
    tb.max_depth = params.max_depth;
    tb.pixel_index = index;
    tb.img_size = params.width * params.height;

    if (params.denoise_active && params.denoise_albedo_buffer && params.denoise_normal_buffer) {
      radiance = integrator.sample<true, true>(
          ray, params.scene, sampler, tb,
          params.denoise_albedo_buffer, params.denoise_normal_buffer,
          index, params.sampleCount, &params.camera, params.path_guiding_mode);
    } else {
      radiance = integrator.sample<true, false>(
          ray, params.scene, sampler, tb,
          nullptr, nullptr, -1, 1, nullptr, params.path_guiding_mode);
    }
  } else {
    if (params.denoise_active && params.denoise_albedo_buffer && params.denoise_normal_buffer) {
      radiance = integrator.sample<false, true>(
          ray, params.scene, sampler, TrainingBuffers(),
          params.denoise_albedo_buffer, params.denoise_normal_buffer,
          index, params.sampleCount, &params.camera, params.path_guiding_mode);
    } else {
      radiance = integrator.sample<false, false>(
          ray, params.scene, sampler);
    }
  }

  accumulate_and_write(index, ray, radiance);
}

extern "C" __global__ void __raygen__volpath() {
  uint3 idx = optixGetLaunchIndex();

  if (idx.x >= params.width || idx.y >= params.height)
    return;

  int index;
  Sampler sampler;
  Ray3f ray = setup_ray(idx, index, sampler);

  EmitterSampler light_sampler(params.light_sampler_type);
  VolumetricPath integrator(params.max_depth, params.rr_depth, false, light_sampler);
  Color3f radiance = integrator.sample(ray, params.scene, sampler);

  accumulate_and_write(index, ray, radiance);
}

extern "C" __global__ void __closesthit__ch() {
  unsigned int p0 = optixGetPayload_0();
  unsigned int p1 = optixGetPayload_1();

  unsigned long long packed = (static_cast<unsigned long long>(p1) << 32) |
                              static_cast<unsigned long long>(p0);
  SurfaceIntersection *rec = reinterpret_cast<SurfaceIntersection *>(packed);

  unsigned int primIdx = optixGetPrimitiveIndex();
  const Triangle &tri = params.scene.triangles[primIdx];

  Ray3f ray(Point3f(optixGetWorldRayOrigin().x, optixGetWorldRayOrigin().y,
                    optixGetWorldRayOrigin().z),
            Vector3f(optixGetWorldRayDirection().x,
                     optixGetWorldRayDirection().y,
                     optixGetWorldRayDirection().z));

  float2 bary = optixGetTriangleBarycentrics();
  tri.populate_intersection(ray, optixGetRayTmax(), bary.x, bary.y, *rec,
                            params.scene.use_vertex_normals, (int)primIdx);
}

extern "C" __global__ void __miss__ms() {
  // bvh.intersect handles misses by checking rec.is_valid().
  // We don't need to do anything here.
}

extern "C" __global__ void __anyhit__shadow() {
  unsigned int target_mesh_id = optixGetPayload_0();
  unsigned int primIdx = optixGetPrimitiveIndex();
  const Triangle &tri = params.scene.triangles[primIdx];

  if (tri.mesh_id == (int)target_mesh_id) {
    optixIgnoreIntersection();
  }

  if (tri.material_id >= 0 && tri.material_id < (int)params.scene.materialCount) {
    int mat_type = params.scene.materials[tri.material_id].type;
    if (mat_type == BSDF_ID_NULL) {
      optixIgnoreIntersection();
    }
  }

  optixSetPayload_1(1);
  optixTerminateRay();
}

extern "C" __global__ void __miss__shadow() {
  optixSetPayload_1(0);
}
