#pragma once

#include <cmath>

#include "common.cuh"
#include "sampler.cuh"
#include "scene.cuh"
#include "surface_interaction.cuh"


namespace futaba {

struct Phong {
  ::Vector3f lightDir;
  float ambientStrength;
  float diffuseStrength;
  float specularStrength;
  float shininess;

  HD Phong(const ::Vector3f &light_direction = ::Vector3f(1.0f, 1.0f, 1.0f),
           float ambient = 0.12f, float diffuse = 0.88f,
           float specular = 0.35f, float shiny = 32.0f)
      : lightDir(normalize(light_direction)), ambientStrength(ambient),
        diffuseStrength(diffuse), specularStrength(specular),
        shininess(shiny) {}

  HD Color3f sample(const Ray &ray, const Scene &scene, Sampler &) const {
    SurfaceIntersection si;
    if (!scene.intersect(ray, ray.mint, ray.maxt, si)) {
      return Color3f(0.0f);
    }

    ::Vector3f n = normalize(si.n);
    if (dot(ray.d, n) > 0.0f)
      n = -n;

    const ::Vector3f viewDir   = normalize(-ray.d);

    const Color3f lightColor(1.0f);

    const float ndotl = fmaxf(dot(n, lightDir), 0.0f);
    const ::Vector3f reflectDir = 2.0f * dot(n, lightDir) * n - lightDir;
    const float rdotv = fmaxf(dot(normalize(reflectDir), viewDir), 0.0f);

    Color3f diffuse  = si.albedo * (ambientStrength + diffuseStrength * ndotl);
    Color3f specular = si.specular * (specularStrength * powf(rdotv, shininess));

    return (diffuse + specular) * lightColor + si.emission;
  }
};

} // namespace futaba

#ifndef FUTABA_OPTIX_DEVICE_PROGRAMS
#include "gui.h"
#include "integrator_ui.h"

#include <nanogui/nanogui.h>

namespace {

using namespace nanogui;

constexpr float kMinPhongStrength = 0.f;
constexpr float kMaxPhongStrength = 2.f;
constexpr float kMinPhongShininess = 1.f;
constexpr float kMaxPhongShininess = 128.f;

static float toUnitRange(float value, float minVal, float maxVal) {
  float t = (value - minVal) / (maxVal - minVal);
  if (t < 0.f)
    t = 0.f;
  if (t > 1.f)
    t = 1.f;
  return t;
}

static float fromUnitRange(float t, float minVal, float maxVal) {
  if (t < 0.f)
    t = 0.f;
  if (t > 1.f)
    t = 1.f;
  return minVal + t * (maxVal - minVal);
}

class PhongIntegratorUiPanel final : public IntegratorUiPanel {
public:
  int mode() const override { return futaba::INTEGRATOR_PHONG; }
  const char *label() const override { return "Phong"; }

  void initialize(FutabaScreen &screen) override {
    m_window = new Window(&screen, "Phong Controls");
    m_window->setPosition(nanogui::Vector2i(245, 15));
    m_window->setLayout(new GroupLayout(10, 5, 5, 5));

    addSlider(screen, "Ambient", kMinPhongStrength, kMaxPhongStrength,
          [](FutabaScreen &s) { return s.getPhongAmbient(); },
          [](FutabaScreen &s, float value) { s.setPhongAmbient(value); });
    addSlider(screen, "Diffuse", kMinPhongStrength, kMaxPhongStrength,
          [](FutabaScreen &s) { return s.getPhongDiffuse(); },
          [](FutabaScreen &s, float value) { s.setPhongDiffuse(value); });
    addSlider(screen, "Specular", kMinPhongStrength, kMaxPhongStrength,
          [](FutabaScreen &s) { return s.getPhongSpecular(); },
          [](FutabaScreen &s, float value) { s.setPhongSpecular(value); });
    addSlider(screen, "Shininess", kMinPhongShininess, kMaxPhongShininess,
          [](FutabaScreen &s) { return s.getPhongShininess(); },
          [](FutabaScreen &s, float value) { s.setPhongShininess(value); });

    renderUI(screen);
  }

  void renderUI(FutabaScreen &screen) override {
    if (m_window)
      m_window->setVisible(screen.getIntegratorMode() == futaba::INTEGRATOR_PHONG);
  }

private:
  template <typename Getter, typename Setter>
  void addSlider(FutabaScreen &screen, const std::string &name, float minVal,
           float maxVal, Getter getter, Setter setter) {
    new Label(m_window, name, "sans-bold");

    Widget *panel = new Widget(m_window);
    panel->setLayout(new BoxLayout(Orientation::Horizontal, Alignment::Middle, 0, 10));

    Slider *slider = new Slider(panel);
    slider->setFixedWidth(120);

    Label *valueLabel = new Label(panel, std::to_string(getter(screen)));
    slider->setValue(toUnitRange(getter(screen), minVal, maxVal));
    slider->setCallback([&screen, minVal, maxVal, valueLabel, setter](float t) {
      const float value = fromUnitRange(t, minVal, maxVal);
      valueLabel->setCaption(std::to_string(value));
      setter(screen, value);
      screen.clearFilm();
    });
  }

  Window *m_window = nullptr;
};

IntegratorUiRegistrar g_registerPhongUi([]() { return std::make_unique<PhongIntegratorUiPanel>(); });

} // namespace
#endif
