#pragma once

#include <functional>
#include <memory>
#include <string>
#include <vector>
#include <algorithm>

class FutabaScreen;

class IntegratorUiPanel {
public:
    virtual ~IntegratorUiPanel() = default;

    virtual int mode() const = 0;
    virtual const char *label() const = 0;
    virtual void initialize(FutabaScreen &screen) = 0;
    virtual void renderUI(FutabaScreen &screen) = 0;
};

class IntegratorUiController {
public:
    using PanelFactory = std::function<std::unique_ptr<IntegratorUiPanel>()>;

    static void registerPanel(PanelFactory factory);

    void initialize(FutabaScreen &screen);

    const std::vector<std::string> &labels() const;

    size_t indexForMode(int mode) const;

    int modeForIndex(size_t index) const;

    void setActiveIndex(size_t index, FutabaScreen &screen);

    void setActiveMode(int mode, FutabaScreen &screen);

    void renderUI(FutabaScreen &screen);

private:
    struct Entry {
        int mode;
        std::string label;
        std::unique_ptr<IntegratorUiPanel> panel;
    };

    std::vector<Entry> m_entries;
    std::vector<std::string> m_labels;
    bool m_initialized = false;
};

class IntegratorUiRegistrar {
public:
    explicit IntegratorUiRegistrar(IntegratorUiController::PanelFactory factory);
};

#ifndef FUTABA_OPTIX_DEVICE_PROGRAMS
class NoopIntegratorUiPanel final : public IntegratorUiPanel {
public:
    NoopIntegratorUiPanel(int mode, const char *label)
        : m_mode(mode), m_label(label) {}

    int mode() const override { return m_mode; }
    const char *label() const override { return m_label; }
    void initialize(FutabaScreen &) override {}
    void renderUI(FutabaScreen &) override {}

private:
    int m_mode;
    const char *m_label;
};

inline void registerNoopIntegratorUi(int mode, const char *label) {
    IntegratorUiController::registerPanel([mode, label]() {
        return std::make_unique<NoopIntegratorUiPanel>(mode, label);
    });
}
#endif

#define FUTABA_REGISTER_INTEGRATOR_UI(Type) \
    static IntegratorUiRegistrar reg_##Type([]() { return std::make_unique<Type>(); })
